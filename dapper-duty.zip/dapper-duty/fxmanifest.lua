fx_version 'bodacious'

game 'rdr3'

rdr3_warning 'I understand that RedM Updates and that my work might become incompatible with RedM Updates.'

client_scripts {
  'config.lua',
  'client.lua'
}

server_scripts {
  'config.lua',
  'server.lua'
}