

local playerjob
local playerjobgrade
local online

RegisterNetEvent("dapper-duty:notification")
AddEventHandler("dapper-duty:notification", function(message)
	nuiNotification(message)
end)