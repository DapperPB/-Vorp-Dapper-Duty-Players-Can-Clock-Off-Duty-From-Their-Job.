Config = {}

Config.Script_Name = "dapper-duty"

Config.Trigger_With_Command = true
Config.Trigger_With_Command = "duty"

