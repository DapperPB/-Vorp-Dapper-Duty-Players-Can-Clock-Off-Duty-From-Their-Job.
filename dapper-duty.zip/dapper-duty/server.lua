local VorpCore = {}
TriggerEvent("getCore",function(core)
	VorpCore = core
end)

RegisterCommand('duty', function(source, args, rawCommand)
    local _source = source
    local Character = VorpCore.getUser(_source).getUsedCharacter
    local job = Character.job
    if job == 'police' then
		TriggerClientEvent('dapper-duty:police', _source)
	elseif job == 'doctor' then
		TriggerClientEvent('dapper-duty:doctor', _source)
	elseif job == 'bastille' then
		TriggerClientEvent('dapper-duty:bastille', _source)
	elseif job == 'marshals' then
		TriggerClientEvent('dapper-duty:marshals', _source)
	end
end)

RegisterServerEvent('dapper-duty:police')
AddEventHandler( 'dapper-duty:police', function(job)

		local _source = source
		local User = VorpCore.getUser(_source).getUsedCharacter
		
		
	if xPlayer.job.id == 'police' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('offpolice',0)
	elseif xPlayer.job.id == 'police' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('offpolice',1)
	elseif xPlayer.job.id == 'police' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('offpolice',2)
	elseif xPlayer.job.id == 'police' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('offpolice',3)
	elseif xPlayer.job.id == 'police' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('offpolice',4)
	elseif xPlayer.job.id == 'police' and xPlayer.job.jobgrade == 5 then
		xPlayer.setJob('offpolice',5)
	elseif xPlayer.job.id == 'police' and xPlayer.job.jobgrade == 6 then
		xPlayer.setJob('offpolice',6)
	end
	
	if xPlayer.job.id == 'offpolice' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('police',0)
	elseif xPlayer.job.id == 'offpolice' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('police',1)
	elseif xPlayer.job.id == 'offpolice' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('police',2)
	elseif xPlayer.job.id == 'offpolice' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('police',3)
	elseif xPlayer.job.id == 'offpolice' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('police',4)
	elseif xPlayer.job.id == 'offpolice' and xPlayer.job.jobgrade == 5 then
		xPlayer.setJob('police',5)
	elseif xPlayer.job.id == 'offpolice' and xPlayer.job.jobgrade == 6 then
		xPlayer.setJob('police',6)
	end
end)

RegisterServerEvent('dapper-duty:doctor')
AddEventHandler( 'duty:doctor', function(job)

		local _source = source
		local User = VorpCore.getUser(_source).getUsedCharacter
		
		
	if xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('offdoctor',0)
	elseif xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('offdoctor',1)
	elseif xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('offdoctor',2)
	elseif xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('offdoctor',3)
	end
	
	if xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('doctor',0)
	elseif xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('doctor',1)
	elseif xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('doctor',2)
	elseif xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('doctor',3)
	end
end)

RegisterServerEvent('dapper-duty:doctor')
AddEventHandler( 'duty:doctor', function(job)

		local _source = source
		local User = VorpCore.getUser(_source).getUsedCharacter
		
		
	if xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('offdoctor',0)
	elseif xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('offdoctor',1)
	elseif xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('offdoctor',2)
	elseif xPlayer.job.id == 'doctor' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('offdoctor',3)
	end
	
	if xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('doctor',0)
	elseif xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('doctor',1)
	elseif xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('doctor',2)
	elseif xPlayer.job.id == 'offdoctor' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('doctor',3)
	end
end)

RegisterServerEvent('dapper-duty:bastille')
AddEventHandler( 'duty:bastille', function(job)

		local _source = source
		local User = VorpCore.getUser(_source).getUsedCharacter
		
		
	if xPlayer.job.id == 'bastille' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('offbastille',0)
	elseif xPlayer.job.id == 'bastille' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('offbastille',1)
	elseif xPlayer.job.id == 'bastille' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('offbastille',2)
	elseif xPlayer.job.id == 'bastille' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('offbastille',3)
	elseif xPlayer.job.id == 'bastille' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('offbastille',4)
	elseif xPlayer.job.id == 'bastille' and xPlayer.job.jobgrade == 5 then
		xPlayer.setJob('offbastille',5)
	end
	
	if xPlayer.job.id == 'offbastille' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('bastille',0)
	elseif xPlayer.job.id == 'offbastille' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('bastille',1)
	elseif xPlayer.job.id == 'offbastille' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('bastille',2)
	elseif xPlayer.job.id == 'offbastille' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('bastille',3)
	elseif xPlayer.job.id == 'offbastille' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('bastille',4)
	elseif xPlayer.job.id == 'offbastille' and xPlayer.job.jobgrade == 5 then
		xPlayer.setJob('bastille',5)
	end
end)

RegisterServerEvent('dapper-duty:marshals')
AddEventHandler( 'duty:marshals', function(job)

		local _source = source
		local User = VorpCore.getUser(_source).getUsedCharacter
		
		
	if xPlayer.job.id == 'marshals' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('offmarshals',0)
	elseif xPlayer.job.id == 'marshals' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('offmarshals',1)
	elseif xPlayer.job.id == 'marshals' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('offmarshals',2)
	elseif xPlayer.job.id == 'marshals' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('offmarshals',3)
	elseif xPlayer.job.id == 'marshals' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('offmarshals',4)
	elseif xPlayer.job.id == 'marshals' and xPlayer.job.jobgrade == 5 then
		xPlayer.setJob('offmarshals',5)
	end
	
	if xPlayer.job.id == 'offmarshals' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('marshals',0)
	elseif xPlayer.job.id == 'offmarshals' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('marshals',1)
	elseif xPlayer.job.id == 'offmarshals' and xPlayer.job.jobgrade == 2 then
		xPlayer.setJob('marshals',2)
	elseif xPlayer.job.id == 'offmarshals' and xPlayer.job.jobgrade == 3 then
		xPlayer.setJob('marshals',3)
	elseif xPlayer.job.id == 'offmarshals' and xPlayer.job.jobgrade == 4 then
		xPlayer.setJob('marshals',4)
	elseif xPlayer.job.id == 'offmarshals' and xPlayer.job.jobgrade == 5 then
		xPlayer.setJob('marshals',5)
	end
end)

		