INSERT INTO `container` (`id`, `name`, `items`) VALUES
	('offpolice', 'Off-Duty'),
	('offdoctor', 'Off-Duty')
	
INSERT INTO `society` (`job`, `jobgrade`, `salary`) VALUES
	('offpolice', 0, 0),
	('offpolice', 1, 0),
	('offpolice', 2, 0),
	('offpolice', 3, 0),
	('offpolice', 4, 0),
	('offpolice', 5, 0),
	('offpolice', 6, 0),
	('offdoctor', 0, 0),
	('offdoctor', 1, 0),
	('offdoctor', 2, 0),
	('offdoctor', 3, 0),
	('offrgs', 0, 0);
	('offrgs', 1, 0);
	('offrgs', 2, 0);
	('offrgs', 3, 0);
	('offrgs', 4, 0);
	('offrgs', 5, 0);
	('offrguns', 0, 0);
	('offrguns', 1, 0);
	('offrguns', 2, 0);
	('offrguns', 3, 0);
	('offrguns', 4, 0);
	('offrguns', 5, 0);
	('offbastille', 0, 0);
	('offbastille', 1, 0);
	('offbastille', 2, 0);
	('offbastille', 3, 0);
	('offbastille', 4, 0);
	('offbastille', 5, 0);
	('offmarshals', 0, 0);
	('offmarshals', 1, 0);
	('offmarshals', 2, 0);
	('offmarshals', 3, 0);
	('offmarshals', 4, 0);
	('offmarshals', 5, 0);