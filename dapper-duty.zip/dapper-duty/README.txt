This is a very basic Off/On Duty script.



Developer Notes:
- command should be /duty.
- feel free to configure it to your hearts content.

Server Main Notes:
- Please make sure to add in your jobs
  in the RegisterCommand.



------Blank Samples (for those who wanna copy pasta)------

RegisterServerEvent('dapper-duty:insertjob')
AddEventHandler( 'dapper-duty:police', function(job)

		local _source = source
		local User = VorpCore.getUser(_source).getUsedCharacter
		
		
	if xPlayer.job.id == 'insertjob' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('offinsertjob',0)
	elseif xPlayer.job.id == 'insertjob' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('offinsertjob',1)

	end
	
	if xPlayer.job.id == 'offinsertjob' and xPlayer.job.jobgrade == 0 then
		xPlayer.setJob('insertjob',0)
	elseif xPlayer.job.id == 'offinsertjob' and xPlayer.job.jobgrade == 1 then
		xPlayer.setJob('insertjob',1)

	end
end)



Special Thanks to:

Mysticwolve for testing.
Mayne, Six65nine, Adz, Sabbo2001 for letting me learn from them.


If you have any problems or issues tweet me @DapperPaperBag























I want to thank @Mayne @Six65Nine @Sabbo2001 @Adz 
for helping me by allowing me to learn from their scripts.
Without their help, this wouldn't be possible.






















